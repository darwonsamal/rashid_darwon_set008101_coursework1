


/*TO DO FUCING FIX*/






function  encrypt(text, key)
{

    var cipher = '';

    for(var i = 0; i < text.length; i++)
    {
        var letter = text[i];

        var code = letter.charCodeAt(i);

        if((code >= 65) && (code <= 90))
        {
          code = (((code - 65 + key) % 26) + 65);
        }

        if((code >= 97) && (code <= 122))
        {
            code = (((code - 97 + key) % 26) + 97);
        }

        code = String.fromCharCode(code);

        cipher += code;

        console.log(cipher);
    }


      document.getElementById('encryptKey').value = '';
      document.getElementById('decryptKey').value = key;
      document.getElementById('decryptInput').value = cipher;
      document.getElementById('encryptInput').value = '';



}

function doCaesarCipher(text, key, switchCase)
{

	if (Number.isInteger(key)) {
		alert("key is not an integer");
		return;
	}

	if (key < 0 || key >= 26) {
		alert("Shift is out of range");
		return;
	}

	if (switchCase == true)
  {
    key = (26 - key) % 26;
  }

  caesarShift(text, key, switchCase);

}




/* Set the width of the side navigation to 250px */
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
